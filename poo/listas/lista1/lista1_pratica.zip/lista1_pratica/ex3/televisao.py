

class Televisao():
    def __init__(self, volume, canal):
        self.volume = volume
        self.canal = canal